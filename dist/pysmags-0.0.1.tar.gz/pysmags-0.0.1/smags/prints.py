def printdir(obj):
    print(dir(obj))

def printhelp(obj):
    print(help(obj))

def printlen(obj):
    print(len(obj))